package excercise1;


//***********************************To Find the sum of 1 to 50 numbers********************************

public class Question2 {
    int fact = 1;

static void numbers(int n)
{



            System.out.print("Sum of first N  numbers is ==>" + n*(n+1) / 2);
}

    public static void main(String[] args) {


        int n = 5;



     numbers(n);
    }

}
